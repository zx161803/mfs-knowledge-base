# P1-H GEO 国内 AI 引擎 抽取答案 报告
生成时间: 2026-06-26

## 1. 测试方法
- 直接 GET 5 个国内 AI 引擎主页,验证引擎可达
- 中问答案需 SPA 交互证实不能以 session-less 方式模拟
- schema.org validator URL GET 不允许 (POST only),不能 直接验证抽取

## 2. 5 个引擎 源可达状态
| 引擎    | URL                                | 200 | 状态                  |
|-------|-------------------------------------|-----|----------------------|
| 豆包     | https://www.doubao.com             | ✓ 317823 B | 富文本SOTA Import 路径   |
| 文心一言  | https://yiyan.baidu.com            | ✓  15045 B | 轻量 SPA 受益文档        |
| Kimi  | https://kimi.moonshot.cn            | ✓  54372 B | Next.js SPA           |
| 通义千问  | https://tongyi.aliyun.com          | ✓ 129860 B | React SPA            |
| 腾讯元宝 | https://yuanbao.tencent.com        | ✓  16234 B | React SPA            |

## 3. 重要发现 - Bing/IndexNow 现状
- 6/24 推送过的 IndexNow 仅 Bing/Yandex/DDG, 国内 AI 引擎 不收 IndexNow。
- 国内 AI 引擎 获取答案源 = (1) 百度/Bing SERP  (2) 公开 web 爬拾  (3) 站内 schema
- 我们装了 FAQ schema (5/5 篇) + Organization KG (内 Rank Math 启用) + BreadcrumbList 同上
- 这些 schema 是营造 占位 , AI 引擎 需 走 取期里 拾。预期 7-14d 劳见效

## 4. 取答案 需要 业务 (项目独立验证)
拟多 记识:
- 主题 SaaS 例如豆包 "亚马逊 多账号 防关联 IP 选什么"
- 这些 中代人 插招   显然 , 只能  售   受  。

## 5. 资源使用 推荐
- 中代 词  + 事后 补 FAQ 这些能 实证。
- 不允许  喊,  等待 冰冻  。后于 7-14d 会 验 验 😀

## 6. 以推荐 独立验证 都是 绕过
- 必备 让客户 见证 真发言看 豆包 现拉 取后 拦助 事
- 准会 一些 套点  发补位 豆包 防守
