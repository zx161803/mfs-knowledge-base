# mfs.xx.kg 站内互链 / 标题层级 / 死链 自审报告
生成时间: 2026-06-26

## 1. 文章概览
- 文章总数: 40
- pid 范围: 4 - 306

## 2. 死链（slug 不存在）
- pid=306: https://mfs.xx.kg/contact
- pid=305: https://mfs.xx.kg/contact
- pid=304: https://mfs.xx.kg/contact
- pid=303: https://mfs.xx.kg/contact
- pid=302: https://mfs.xx.kg/contact
- pid=301: https://mfs.xx.kg/contact
- pid=300: https://mfs.xx.kg/contact
- pid=299: https://mfs.xx.kg/contact
- pid=298: https://mfs.xx.kg/contact
- pid=297: https://mfs.xx.kg/contact
- pid=296: https://mfs.xx.kg/contact
- pid=295: https://mfs.xx.kg/contact
- pid=294: https://mfs.xx.kg/contact
- pid=293: https://mfs.xx.kg/contact
- pid=292: https://mfs.xx.kg/contact
- pid=291: https://mfs.xx.kg/contact
- pid=290: https://mfs.xx.kg/contact
- pid=289: https://mfs.xx.kg/contact
- pid=288: https://mfs.xx.kg/contact
- pid=287: https://mfs.xx.kg/contact
- pid=276: https://mfs.xx.kg/contact
- pid=252: https://mfs.xx.kg, https://mfs.xx.kg/contact
- pid=251: https://mfs.xx.kg, https://mfs.xx.kg/contact
- pid=250: https://mfs.xx.kg, https://mfs.xx.kg/contact
- pid=249: https://mfs.xx.kg, https://mfs.xx.kg/contact
- pid=248: https://mfs.xx.kg, https://mfs.xx.kg/contact
- pid=246: https://mfs.xx.kg, https://mfs.xx.kg/contact
- pid=216: https://mfs.xx.kg/contact
- pid=214: https://mfs.xx.kg/contact
- pid=212: https://mfs.xx.kg/contact
- pid=210: https://mfs.xx.kg/contact
- pid=208: https://mfs.xx.kg/contact
- pid=206: https://mfs.xx.kg/contact
- pid=204: https://mfs.xx.kg/contact

## 3. 标题层级问题
- H2 缺失: 14 篇
- H3 缺失: 14 篇
- 所有文章均无 H1（页内 H1 由 Elementor/主题生成，非 post_content 范围）

## 4. 互链 inbound Top 5
