# P1-E/F 百度收录 + 站长帮 + sitemap 状态报告
生成时间: 2026-06-26

## 1. 百度主动推送 (今日配额)
- 推一篇 https://mfs.xx.kg/ip-...scamalytics
- API 返: over quota (HTTP 400 "over quota")
- 含义: 今日 zhanzhangb 已用满 5 篇/天。但 24h 后 配额会自动重置。
- 建议: 6/27 0点后重新推送剩余 5 篇,届时能继续加 5 个 UA
- 之前已推送 5 篇 (pid 287/288/289/290/291 加 pid 292 = 6 篇) - 6/26 当日配额可能已被 282-1 抵完

## 2. sitemap 路由现状
- /?sitemap=1 -> 200 OK  (Rank Math 工作路径)
- /?sitemap=post -> 200 OK, 25 URLs
- 物理 /sitemap.xml -> 404 (IF LiteSpeed 卸载后失效,无 htaccess 绕路用,robots.txt 已指 /?sitemap=1)
- GSC 索引来自物理 sitemap 的报错 — 当前不会发,因 robots.txt 已指 query-string 路由。

## 3. 索引预期 (重启后-7天)
- Google: 6/26 改 CTA + FAQ schema 后,7-14d 内 webhook + 自然爬得能上
- 百度: 主动推送 配额 已重置后补推 + sitemap.xml 不存在仍 200/?sitemap=1
- IndexNow: 都推送过 (HTTP 200, Bing/Yandex/DDG 即刻可说拉取)

## 4. P1-F 抓取频次
- 百度站长后台的"抓取频次"信息在我本会话内没接口取
- 老板手动在 https://ziyuan.baidu.com 后台看
- 同理 GSC 页面后台一句话爬取健康表
